package data;

public class User {
    private String UserID;
    private String UserName;
    private String Password;
    private String UGroupID;
    private String SetUserID;
    private String SetTime;
    private String StartDate;
    private String EndDate;
    private String StartTime;
    private String EndTime;
    private String Updated;

    public String getUserID() {
        return UserID;
    }

    public String getUserName() {
        return UserName;
    }

    public String getPassword() {
        return Password;
    }

    public String getUGroupID() {
        return UGroupID;
    }

    public String getSetUserID() {
        return SetUserID;
    }

    public String getSetTime() {
        return SetTime;
    }

    public String getStartDate() {
        return StartDate;
    }

    public String getEndDate() {
        return EndDate;
    }

    public String getStartTime() {
        return StartTime;
    }

    public String getEndTime() {
        return EndTime;
    }

    public String getUpdated() {
        return Updated;
    }

    public void setUserID(String UserID) {
        this.UserID = UserID;
    }

    public void setUserName(String UserName) {
        this.UserName = UserName;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public void setUGroupID(String UGroupID) {
        this.UGroupID = UGroupID;
    }

    public void setSetUserID(String SetUserID) {
        this.SetUserID = SetUserID;
    }

    public void setSetTime(String SetTime) {
        this.SetTime = SetTime;
    }

    public void setStartDate(String StartDate) {
        this.StartDate = StartDate;
    }

    public void setEndDate(String EndDate) {
        this.EndDate = EndDate;
    }

    public void setStartTime(String StartTime) {
        this.StartTime = StartTime;
    }

    public void setEndTime(String EndTime) {
        this.EndTime = EndTime;
    }

    public void setUpdated(String Updated) {
        this.Updated = Updated;
    }
}
